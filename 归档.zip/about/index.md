---
date: 2018-05-25 08:08:08
---
## 简介
+ VaneHay(名字谐音)/男/1989
+ 籍贯：吕梁
+ 居住城市: 山西/太原/高新区
+ 职业：phper
+ 工作年限：2012.6 - 至今

## 联系我
+ WeChat: VaneHay
+ QQ: Njk0MjUzNDQ0
+ Email：VmFuZUhheUAxNjMuY29t