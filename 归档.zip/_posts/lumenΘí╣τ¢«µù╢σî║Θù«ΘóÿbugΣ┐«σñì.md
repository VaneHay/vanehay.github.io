---
title: lumen项目时区问题bug修复
date: 2018-11-30 12:50:38
tags:
---

## 系统时间正常

``` 
date -R   //Fri, 30 Nov 2018 12:54:14 +0800
```

## mysql时区

``` 
show variables like "%time_zone%";   
```

![mysql时区][./images/mysql_timezone.jpg]

## php版本设置的时区

```
date.timezone = "Asia/Shanghai"
```

## 修改内容：

```
APP_TIMEZONE=PRC    //lumen 项目 .env 配置文件
'timezone'  => env('DB_TIMEZONE', '+08:00'),  //vendor/laravel/lumen-framework/config/database.php
```

