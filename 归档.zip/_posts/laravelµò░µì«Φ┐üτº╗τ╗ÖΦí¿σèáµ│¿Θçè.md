---
title: laravel数据迁移给表加注释
date: 2018-08-29 14:54:17
tags:
- larval
categories:
- php
---

`laravel` 数据迁移 `migrations` 下文件增加数据表注释方法：

引用DB

``` php
use Illuminate\Support\Facades\DB;   //文件开头增加

public function up()
{
    Schema::create('users', function (Blueprint $table) {
        $table->increments('id');
        $table->timestamps();
    });
  
    DB::statement("ALTER TABLE `users` comment'用户表'"); // 表注释
}
```

